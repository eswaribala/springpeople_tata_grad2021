package com.SessionTraining.Entity;

public abstract class Worker {

    protected int salaryRate;
    protected String name;

    Worker(String name,int salaryRate) {
        this.name = name;
        this.salaryRate = salaryRate;
    }
    public abstract int Pay(int hours);
}
