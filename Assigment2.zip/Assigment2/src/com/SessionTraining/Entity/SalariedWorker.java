package com.SessionTraining.Entity;

public class SalariedWorker extends Worker{
    public SalariedWorker(String name, int salaryRate) {
        super(name, salaryRate);
    }

    @Override
    public int Pay(int hours) {
        hours = Math.min(40,hours);
        return this.salaryRate * hours;
    }
}
