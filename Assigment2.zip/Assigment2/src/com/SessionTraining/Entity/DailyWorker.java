package com.SessionTraining.Entity;

public class DailyWorker extends Worker{
    public DailyWorker(String name, int salaryRate) {
        super(name, salaryRate);
    }

    @Override
    public int Pay(int hours) {
        return this.salaryRate * hours;
    }
}
