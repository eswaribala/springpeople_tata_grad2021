package com.SessionTraining;

import com.SessionTraining.Entity.DailyWorker;
import com.SessionTraining.Entity.SalariedWorker;
import com.SessionTraining.Entity.Worker;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<Worker> workers = new ArrayList<Worker>();
        workers.add(new SalariedWorker("SalariedWorker 1",40));
        workers.add(new SalariedWorker("SalariedWorker 2",50));
        workers.add(new SalariedWorker("SalariedWorker 3",60));
        workers.add(new DailyWorker("DailyWorker 1",25));
        workers.add(new DailyWorker("DailyWorker 2",35));
        workers.add(new DailyWorker("DailyWorker 3",45));

        Long operationCost = 0L;
        //Assuming each worker works for an duration of 45 hours in a week
        for(Worker worker : workers) {
            operationCost += worker.Pay(45);
        }
        System.out.println("Cost to Company : " + operationCost);
    }
}
