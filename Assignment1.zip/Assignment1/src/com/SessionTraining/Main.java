package com.SessionTraining;

import java.util.Scanner;

public class Main {

    public static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        int input = scanner.nextInt();
        int productCode = scanner.nextInt();
        int quantity = scanner.nextInt();
        double totalRetailValue = 0.00;
        int[] Quantities = new int[3];
        while(input-- > 0) {
            Quantities[productCode-1] += quantity;
            switch(productCode){
                case 1 :
                    totalRetailValue += (quantity * 22.5);
                    break;
                case 2 :
                    totalRetailValue += (quantity * 44.50);
                    break;
                case 3:
                    totalRetailValue += (quantity * 9.98);
                    break;
                default:
                    break;
            }
        }
        System.out.println("Total Retail Value Sold : " + String.valueOf(totalRetailValue));
    }
}
