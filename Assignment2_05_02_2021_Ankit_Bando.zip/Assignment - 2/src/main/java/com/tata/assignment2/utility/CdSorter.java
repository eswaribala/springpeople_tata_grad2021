package com.tata.assignment2.utility;

import com.tata.assignment2.models.Cd;

import java.util.Comparator;

public class CdSorter implements Comparator<Cd> {

    @Override
    public int compare(Cd o1, Cd o2) {
        return o1.getSingerName().compareTo(o2.getSingerName());
    }
}
