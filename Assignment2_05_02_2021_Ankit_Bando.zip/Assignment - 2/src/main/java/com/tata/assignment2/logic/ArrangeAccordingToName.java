package com.tata.assignment2.logic;

import com.tata.assignment2.models.Cd;
import com.tata.assignment2.utility.CdSorter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ArrangeAccordingToName {
    public static List<Cd> getSortedItems(List<Cd> cdList) {
        Collections.sort(cdList, new CdSorter());
        return cdList;
    }

    public static void main(String[] args) {
        List<Cd> cdList = new ArrayList<>();

        cdList.add(new Cd("Drivers License", "Olivia Rodrigo"));
        cdList.add(new Cd("Mood", "24kGoldn Featuring iann dior"));
        cdList.add(new Cd("Blinding Lights", "The Weeknd"));
        cdList.add(new Cd("34+35", "Ariana Grande"));
        cdList.add(new Cd("Levitating", "Dua Lipa Featuring DaBaby"));
        cdList.add(new Cd("Positions", "Ariana Grande"));

        cdList.stream()
                .sorted(Comparator.comparing(Cd::getSingerName))
                .forEach(System.out::println);
    }
}
