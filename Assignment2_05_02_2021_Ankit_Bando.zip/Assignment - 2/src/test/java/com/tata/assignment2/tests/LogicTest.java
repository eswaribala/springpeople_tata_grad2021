package com.tata.assignment2.tests;

import com.tata.assignment2.models.Cd;
import com.tata.assignment2.utility.CdSorter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;


public class LogicTest {
    List<Cd> cdList;

    @BeforeEach
    public void getInstances() {
        cdList = new ArrayList<>();
        cdList.add(new Cd("abc", "Yolo"));
        cdList.add(new Cd("Hello world", "Programmers"));
        cdList.add(new Cd("Drivers License", "Olivia Rodrigo"));
        cdList.add(new Cd("Mood", "24kGoldn Featuring iann dior"));
        cdList.add(new Cd("Blinding Lights", "The Weeknd"));
    }

    @Test
    @DisplayName("Negative Test for cd content")
    public void negativeTestForCdContent() {
        for(Cd cd : cdList) {
            assertNotNull(cd.getTitle());
            assertNotNull(cd.getSingerName());
        }
    }

    // To Validate the Sort method implemented in ArrangeAccordingToName class.
    @Test
    @DisplayName("Test For Sorted Order")
    public void testSortedOrder() {
        // A custom sorting impl. using lambda function
        List<Cd> cdListCopy = new ArrayList<>(cdList);
        Collections.sort(cdList, new CdSorter());

        cdListCopy.sort((Cd cd1, Cd cd2) -> (cd1.getSingerName().compareTo(cd2.getSingerName())));

        Iterator<Cd> iter1 = cdList.iterator();
        Iterator<Cd> iter2 = cdListCopy.iterator();

        while(iter1.hasNext() && iter2.hasNext()) {
            assertEquals(iter1.next(), iter2.next());
        }
    }

    

}
