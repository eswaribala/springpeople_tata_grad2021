package com.tata.assignment.business;


import java.util.Scanner;

public class CalculatePrice {
    public static void main(String[] args) {
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("Total no. of queries");
        n = sc.nextInt();
        float total = 0.0f;

        for(int i = 0; i < n; ++i) {
            int num = sc.nextInt();
            long qty = sc.nextInt();

            switch (num) {
                case 1:
                    total += (float) (qty * 22.50f);
                    break;
                case 2:
                    total += (float) (qty * 44.50f);
                    break;
                case 3:
                    total += (float) (qty * 9.98f);
                    break;
                default:
                    continue;
            }
        }
        System.out.println("Total Price - " + total);
    }
}
