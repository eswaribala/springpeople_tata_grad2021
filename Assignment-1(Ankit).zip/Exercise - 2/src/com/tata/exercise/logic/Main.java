package com.tata.exercise.logic;

import com.tata.exercise.models.DailyWorker;
import com.tata.exercise.models.SalariedWorker;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        DailyWorker person1 = new DailyWorker();
        SalariedWorker person2 = new SalariedWorker();

        person1.setName("abc");
        person1.setSalaryRate(1000.00f);

        person2.setName("def");
        person2.setSalaryRate(980.50f);

        Scanner sc = new Scanner(System.in);

        System.out.print("Hours worked (" + person1.getName() + "): ");
        System.out.println("Total Salary: " + person1.pay(sc.nextInt()));

        System.out.print("Hours worked (" + person2.getName() + "): ");
        System.out.println("Total Salary: " + person2.pay(sc.nextInt()));

    }
}
