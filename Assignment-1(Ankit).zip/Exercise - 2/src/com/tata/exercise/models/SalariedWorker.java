package com.tata.exercise.models;

public class SalariedWorker extends Worker{
    @Override
    public float pay(int hours) {
        return (float) (Math.min(40, hours) * this.getSalaryRate());
    }
}
