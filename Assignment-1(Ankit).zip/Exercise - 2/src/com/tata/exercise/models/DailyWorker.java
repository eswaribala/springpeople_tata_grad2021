package com.tata.exercise.models;

public class DailyWorker extends Worker {
    @Override
    public float pay(int hours) {
        return (float) (hours * this.getSalaryRate());
    }
}
