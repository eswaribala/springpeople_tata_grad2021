package com.TUL.recordsTest;

import com.TUL.records.entity.CD;
import com.TUL.records.entity.CDCollection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class CDTests {

    private CDCollection cdCollection;

    @BeforeEach
    public void TestSetup(){
        this.cdCollection = new CDCollection();
    }

    @Test
    public void TestSize(){
        assertTrue(cdCollection.getRecords().size() == 0);
        cdCollection.addRecord(new CD("Random1","Random1"));
        assertTrue(cdCollection.getRecords().size() == 1);
    }

    @ParameterizedTest
    @MethodSource("provideParameters")
    public void testAmountValuePositive(String Song,String Name){
        this.cdCollection.addRecord(new CD(Song,Name));
        assertTrue(this.cdCollection.getRecords().size() > 0);
    }

    private static Stream<Arguments> provideParameters(){
        return Stream.of(Arguments.of("Song1","Name1"),
                Arguments.of("Song2","Name2"),
                Arguments.of("Song3","Name3"),
                Arguments.of("Song4","Name4"),
                Arguments.of("Song5","Name5"));
    }

    @Test
    public void checkOrder(){
        this.cdCollection.addRecord(new CD("5","5"));
        this.cdCollection.addRecord(new CD("4","4"));
        this.cdCollection.addRecord(new CD("3","3"));
        this.cdCollection.addRecord(new CD("2","2"));
        this.cdCollection.addRecord(new CD("1","1"));
        this.cdCollection.sortRecord();
        assertTrue(this.cdCollection.getRecords().get(4) != null &&
                this.cdCollection.getRecords().get(4).getSinger() == "5");
    }
    @AfterEach
    public void TestCleanUp(){
        this.cdCollection = null;
    }
}
