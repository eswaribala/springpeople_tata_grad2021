package com.TUL.records.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CDCollection {
    private List<CD> cdCollection;

    public CDCollection(){
        this.cdCollection = new ArrayList<CD>();
    }

    public void addRecord(CD cd){
        this.cdCollection.add(cd);
    }

    public void sortRecord(){
        Collections.sort(this.cdCollection, new Comparator<CD>() {
            @Override
            public int compare(CD o1, CD o2) {
                if(o1.getSinger().compareTo(o2.getSinger()) == 0)
                    return o1.getTitle().compareTo(o2.getTitle());
                return o1.getSinger().compareTo(o2.getSinger());
            }
        });
    }

    public List<CD> getRecords(){
        return cdCollection;
    }
}
