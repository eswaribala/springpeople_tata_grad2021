package com.TUL.records;

import com.TUL.records.entity.CD;
import com.TUL.records.entity.CDCollection;

public class Main {

    public static void main(String[] args){
        CDCollection cdCollection = new CDCollection();
        cdCollection.addRecord(new CD("Can't Stop the Feeling","Justin Timberlake"));
        cdCollection.addRecord(new CD("Say Something","Justin Timberlake"));
        cdCollection.addRecord(new CD("Blank Space","Taylor Swift"));
        cdCollection.addRecord(new CD("Venom","Eminem"));
        cdCollection.addRecord(new CD("East of Eden","Zella Day"));

        cdCollection.sortRecord();
        cdCollection.getRecords().stream().forEach((R1)->System.out.println(R1.toString()));
    }
}
