package com.tata.assignment.test1;

import com.tata.assignment.Business.Cdsorter;
import com.tata.assignment.Dao.CdDao;
import com.tata.assignment.Dao.Cdimp;
import com.tata.assignment.models.CdApp;
import com.tata.assignment.utility.Cdmain;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Random;
import static org.junit.jupiter.api.Assertions.*;
public class test2 {


    private CdApp cd1,cd2,cd3,cd4;
    private Cdsorter cds1,cds2;
    private CdDao cdDao1,cdDao2;

    private Cdmain cdd1,cdd2;
    @BeforeEach
    public void getInstance(){
        cd1 =new CdApp();
        cd1.setTitle("JASH");
        cd1.setSinger("Arijit singh");

        cd2 =new CdApp("Shah","Arijiit");
//        cd2.setSinger("Arijit singh");
//        cd2.setTitle("SHAH");
        //cd3=new CdApp();
        cd4 = new CdApp("ada","dad");
        cds1=new Cdsorter();
        cds2=new Cdsorter();
        cdDao1 =new Cdimp();
        cdDao2=new Cdimp();
        cdd1=new Cdmain();
        cdd2=new Cdmain();


    }

    @Test
    @DisplayName("UNIQUETITLE")
    public void testtitleunique(){
        assertNotEquals(cd1.getTitle(),cd2.getTitle());
    }

    @Test
    @DisplayName("UNIQUESinger")
    public void testSingerunique(){
        assertNotEquals(cd1.getSinger(),cd2.getSinger());
    }

    @Test
    @DisplayName("Titlenameshouldnotbezero")
    public void  Ttilenamegreaterthanzer(){
        assertTrue(cd1.getTitle().length()>0);


    }

    @ParameterizedTest
    @ValueSource(strings = {"abcd","avf","hdjadhj","hdahdjasss","fs"})
    public void Ttilenamenotmorethan4(String title)
    {
        cd1.setTitle(title);
        assertTrue(cd1.getTitle().length()>2);
    }
//
    @Test
    public void singerNameShouldNotBeNull()

    {

        assertThrows(NullPointerException.class,()->{cd3.getSinger();

        });

    }
    @Test
    public void titleNameShouldNotBeNull()

    {

        assertThrows(NullPointerException.class,()->{cd3.getTitle();
        });

    }

    @RepeatedTest(5)
    void repeatedTestWithRepetitionInfo(RepetitionInfo repetitionInfo) {

        assertEquals(5, repetitionInfo.getTotalRepetitions());

        assertEquals(cds1.compare(cd1,cd2),cds2.compare(cd1,cd2));

    }

    @Test
    public void NotSame()

    {
        assertEquals(cdDao1.cddao(),cdDao2.cddao());
    }


    @Test
    public void infoNotSame()

    {
        assertEquals(cds1.compare(cd1,cd2),cds2.compare(cd1,cd3));

    }
    @ParameterizedTest
    @CsvFileSource(resources = "jash.csv",numLinesToSkip =1)
    void testwithcsv(String title,String singer){
            assertTrue(title.length()>0);
            assertTrue(singer.length()>0);

    }








}
