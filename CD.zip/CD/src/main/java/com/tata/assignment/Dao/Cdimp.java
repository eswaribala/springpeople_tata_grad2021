package com.tata.assignment.Dao;

import com.tata.assignment.models.CdApp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Cdimp implements CdDao {


    @Override
    public List<CdApp> cddao() {
        return getdata();
    }
    Scanner sc=new Scanner(System.in);


    private List<CdApp> getdata(){
        List<CdApp> getCd = new ArrayList<>();
        CdApp cdd = null;
        for(int i=0;i<5;i++)
        {
            cdd=new CdApp();
            System.out.println("Enter Singer Name");
            cdd.setSinger(sc.next());
            System.out.println("Enter the Title");
            cdd.setTitle(sc.next());
            getCd.add(cdd);
        }
        return getCd;


    }

}
