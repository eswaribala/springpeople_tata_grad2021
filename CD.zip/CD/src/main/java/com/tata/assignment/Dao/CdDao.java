package com.tata.assignment.Dao;

import com.tata.assignment.models.CdApp;

import java.util.List;

public interface CdDao {
    List<CdApp> cddao() ;



}
