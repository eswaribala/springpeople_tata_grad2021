package com.tata.assignment.utility;

import com.tata.assignment.Business.Cdsorter;
import com.tata.assignment.Dao.CdDao;
import com.tata.assignment.Dao.Cdimp;
import com.tata.assignment.models.CdApp;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Cdmain {
    public static void main(String args[]){
        CdDao cdDao=new Cdimp();
        List<CdApp> cdd=cdDao.cddao();
        System.out.println("Before Sorting");
        for(CdApp cd:cdd)
        {
            System.out.println(cd);
        }
        System.out.println("After Sorting");
        Collections.sort(cdd,new Cdsorter());
        for(CdApp cd:cdd)
        {
            System.out.println(cd);
        }

    }
}
