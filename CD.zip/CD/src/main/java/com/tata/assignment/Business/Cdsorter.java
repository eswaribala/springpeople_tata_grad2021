package com.tata.assignment.Business;

import com.tata.assignment.models.CdApp;

import java.util.Comparator;

public class Cdsorter implements Comparator<CdApp> {
    @Override
    public int compare(CdApp o1, CdApp o2) {
        return o1.getSinger().compareTo(o2.getSinger());
    }
}
