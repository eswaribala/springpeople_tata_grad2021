package com.tata.assignment.dao;

import com.tata.assignment.models.Cd;

import java.util.List;

public interface CdDao {
    List<Cd>getAllInfo();
}
