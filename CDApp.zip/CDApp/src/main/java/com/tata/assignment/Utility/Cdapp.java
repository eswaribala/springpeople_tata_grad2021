package com.tata.assignment.Utility;

import com.tata.assignment.business.CdSorter;
import com.tata.assignment.dao.CdDao;
import com.tata.assignment.dao.CdDaoImpl;
import com.tata.assignment.models.Cd;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Cdapp {
    public static void main(String... args) {
        CdDao cdDao = new CdDaoImpl();
        List<Cd>CdList=cdDao.getAllInfo();
        System.out.println("Before Sorting...");
        for(Cd cd : CdList)
        {
            System.out.println(cd);
        }

        System.out.println("After Sorting...");
        CdList.stream().sorted((c1,c2)->c1.getSinger().compareTo(c2.getSinger())).forEach(System.out::println);

        System.out.println("After Sorting 2...");
        Collections.sort(CdList, new CdSorter());
        for(Cd cd : CdList)
        {
            System.out.println(cd);
        }
    }
}
