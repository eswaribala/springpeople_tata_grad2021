package com.tata.assignment.business;

import com.tata.assignment.models.Cd;

import java.util.Comparator;

public class CdSorter implements Comparator<Cd> {

    @Override
    public int compare(Cd o1, Cd o2) {
        return o1.getSinger().compareTo(o2.getSinger());
    }
}
