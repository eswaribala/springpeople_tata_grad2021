package com.tata.assignment.dao;

import com.tata.assignment.models.Cd;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class CdDaoImpl implements CdDao{
    @Override
    public List<Cd> getAllInfo() {
        return getData();
    }
    Scanner sc=new Scanner(System.in);
    public List<Cd> getData()
    {
        List<Cd>CdList=new ArrayList<>();
        Cd cd = null;
        for(int i=0;i<5;i++)
        {
            cd=new Cd();
            cd.setCdId(new Random().nextInt(10));
            System.out.println("Enter the singer name: ");
            cd.setSinger(sc.next());
            System.out.println("Enter the title: ");
            cd.setTitle(sc.next());
            CdList.add(cd);
        }
        return CdList;
    }
}
