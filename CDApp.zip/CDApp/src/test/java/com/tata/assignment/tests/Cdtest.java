package com.tata.assignment.tests;




import com.tata.assignment.Utility.Cdapp;

import com.tata.assignment.business.CdSorter;

import com.tata.assignment.dao.CdDao;

import com.tata.assignment.dao.CdDaoImpl;

import com.tata.assignment.models.Cd;

import org.junit.jupiter.api.*;

import org.junit.jupiter.params.ParameterizedTest;

import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;




import static org.junit.jupiter.api.Assertions.*;




import java.util.Random;

import java.util.Scanner;




public class Cdtest {

    private Cd Cd1,Cd2,Cd3;

    private CdDao cddao1,cddao2;

    private CdSorter cds1,cds2;

    private Cdapp cda1,cda2;




    @BeforeEach

    public void getInstance()

    {

        Scanner sc = new Scanner(System.in);

        Cd1=new Cd();

//        System.out.println("Enter singer1 name");

        Cd1.setCdId(new Random().nextInt(10));

        Cd1.setTitle("asdf");

        Cd1.setSinger("asdd");

        Cd2 = new Cd("qaz","wsx",new Random().nextInt(10));

//        System.out.println("Enter singer2 name");




        cddao1 = new CdDaoImpl();

        cddao2 = new CdDaoImpl();




        cds1 = new CdSorter();

        cds2 = new CdSorter();




        cda1 = new Cdapp();

        cda2 = new Cdapp();

    }




    @Test

    @DisplayName("CdId name should not be same ")

    public void idNameNotSame()

    {

        assertNotEquals(Cd1.getCdId(),Cd2.getCdId());

    }




    @Test

    @DisplayName("Title name should not be same")

    public void titleNameNotSame()

    {

        assertNotEquals(Cd1.getTitle(),Cd2.getTitle());

    }




    @Test

    @DisplayName("Singer name should not be same")

    public void singerNameNotSame()

    {

        assertNotEquals(Cd1.getSinger(),Cd2.getSinger());

    }




    @ParameterizedTest

    @ValueSource(strings = {"abcs","qwert","asdfg","xcvb"})

    public void titleNameLengthNotMoreThan5(String title)

    {

        Cd1.setTitle(title);

        assertTrue(Cd1.getTitle().length()<=5);

    }




    @Test

    public void singerNameShouldNotBeNull()

    {

        assertThrows(NullPointerException.class,()->{Cd3.getSinger();

        });

    }




    @Test

    public void titleNameShouldNotBeNull()

    {

        assertThrows(NullPointerException.class,()->{Cd3.getTitle();

        });

    }




    @Test

    public void dataNotSame()

    {




        assertNotEquals(cddao1.getAllInfo(),cddao2.getAllInfo());

    }




    @Test

    public void infoNotSame()

    {




        assertNotEquals(cds1.compare(Cd1,Cd2),cds2.compare(Cd1,Cd3));

    }




    @RepeatedTest(5)

    void repeatedTestWithRepetitionInfo(RepetitionInfo repetitionInfo) {

        assertEquals(5, repetitionInfo.getTotalRepetitions());

        assertEquals(cds1.compare(Cd1,Cd2),cds2.compare(Cd1,Cd2));

    }




    // Use CSV

    @ParameterizedTest

    @CsvFileSource(resources = "/com.tata.assignment.tests/cddata.csv", numLinesToSkip = 1)

    void testWithCsvFileSource(int cdId, String title, String singer) {

        assertTrue(cdId > 0);

        assertFalse(singer.matches(".*[0-9]+.*"));

    }



}