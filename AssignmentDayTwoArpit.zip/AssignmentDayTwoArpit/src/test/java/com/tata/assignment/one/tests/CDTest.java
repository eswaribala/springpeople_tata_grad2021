package com.tata.assignment.one.tests;

import com.assignment.one.business.CDSorter;
import com.assignment.one.models.CD;
import com.assignment.one.singer.CDSinger;
import com.assignment.one.singer.CDSingerImpl;
import com.assignment.one.utility.CDApp;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Random;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class CDTest {
    private static CD cd1, cd2, cd3;
    private CDSinger cdSinger1, cdSinger2;
    private CDSorter cdSorter1, cdSorter2;
    private CDApp cdApp1, cdApp2, cdApp3;

    @BeforeEach
    public void getInstance() {
        Scanner sc = new Scanner(System.in);

        // Using NoArgs
        cd1 = new CD();
        cd1.setCdId(new Random().nextInt(1000));
        //System.out.println(cd1.getCdId());
        cd1.setTitle("Listen");
        cd1.setSinger("Arijit");

        // Using AllArgs
        cd2 = new CD(new Random().nextInt(1000), "NewSongs", "Arman");
        //System.out.println(cd2.getCdId());

        //cd3 = new CD();
        //cd3.setCdId(new Random().nextInt(1000));
        //System.out.println(cd2.getCdId());

        cdSinger1 = new CDSingerImpl();
        cdSinger2 = new CDSingerImpl();

        cdSorter1 = new CDSorter();
        cdSorter2 = new CDSorter();

        cdApp1 = new CDApp();
        cdApp2 = new CDApp();

    }

    // CD Id should be unique
    @Test
    @DisplayName("Test CD Id Should be Unique")
    public void testCDIdUnique() {
        assertNotEquals(cd1.getCdId(), cd2.getCdId());
    }

    // Title name should not same
    @Test
    @DisplayName("Test Cd Title Should be Unique")
    public void testTitleUnique() {
        assertNotEquals(cd1.getTitle(), cd2.getTitle());
    }

    // Singer name should not same
    @Test
    @DisplayName("Test Singer Name Should be Unique")
    public void testSingerUnique() {
        assertNotEquals(cd1.getSinger(), cd2.getSinger());
    }

    // Negative Test Singer Name - NullPointer Exception
    @Test
    public void singerNotNull(){
        assertThrows(NullPointerException.class,()->{
            cd3.getSinger();
        });
    }

    // Negative Test Title - NullPointer Exception
    @Test
    public void titleNotNull()
    {
        assertThrows(NullPointerException.class,()->{
            cd3.getTitle();
        });
    }

    // Data of two Singers should not be same
    @Test
    public void dataUnique()
    {
        assertNotEquals(cdSinger1.getAllDetails(),cdSinger2.getAllDetails());
    }

    // Details of two CDs should not be same
    @Test
    public void detailsUnique()
    {
        assertEquals(cdSorter1.compare(cd1,cd2),cdSorter2.compare(cd1,cd2));
    }

    // Parameterized Test for length of title should be less than 10
    @ParameterizedTest
    @ValueSource(strings = {"title1","title10","title2342","titleNewSongs","titlenew"})
    @DisplayName("Title Length should be Less Than Ten")
    public void titleLengthLessThanTen(String title){
        cd1.setTitle(title);
        assertTrue(cd1.getTitle().length()<=10);
    }

    // Use of repeated test
    @RepeatedTest(5)
    void repeatedTestUsage(RepetitionInfo repetitionInfo) {
        assertEquals(5, repetitionInfo.getTotalRepetitions());
        assertEquals(cdSorter1.compare(cd1,cd2),cdSorter2.compare(cd1,cd2));
    }

    // Test CDid>0 & singer name should not contain numbers Through CSV
    @ParameterizedTest
    @CsvFileSource(resources = "cddata.csv", numLinesToSkip = 1)
    void testWithCsvFileSource(int cdId, String title, String singer) {
        assertTrue(cdId > 0);
        assertFalse(singer.matches(".*\\d.*"));
    }

    @AfterEach
    public void testUnReferencedInstance(){
        cd1=null;
        cd2=null;
        cd3=null;
    }
}
