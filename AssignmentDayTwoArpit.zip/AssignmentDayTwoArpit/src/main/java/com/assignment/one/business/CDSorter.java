package com.assignment.one.business;

import com.assignment.one.models.CD;

import java.util.Comparator;

public class CDSorter implements Comparator<CD> {
    @Override
    public int compare(CD c1, CD c2) {
        return c1.getSinger().compareTo(c2.getSinger());
    }
}
