package com.assignment.one.singer;

import com.assignment.one.models.CD;

import java.util.List;

public interface CDSinger {
    List<CD> getAllDetails();
}
