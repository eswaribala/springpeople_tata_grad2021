package com.assignment.one.utility;

import com.assignment.one.business.CDSorter;
import com.assignment.one.singer.CDSinger;
import com.assignment.one.singer.CDSingerImpl;
import com.assignment.one.models.CD;

import java.util.Collections;
import java.util.List;

public class CDApp {
    public static void main(String[] args) {
        CDSinger cdSinger = new CDSingerImpl();
        List<CD> CDList = cdSinger.getAllDetails();
        System.out.println("\nBefore Sorting:");
        for(CD cd: CDList){
            System.out.println(cd);
        }
        System.out.println("\nAfter Sorting:");
        // Method 1
        Collections.sort(CDList, new CDSorter());
        for(CD cd: CDList){
            System.out.println(cd);
        }

        // Method 2
        //CDList.stream().sorted((c1,c2)->c1.getSinger().compareTo(c2.getSinger())).forEach(System.out::println);



    }
}
