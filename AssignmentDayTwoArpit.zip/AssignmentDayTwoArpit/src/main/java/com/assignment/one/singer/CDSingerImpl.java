package com.assignment.one.singer;

import com.assignment.one.models.CD;

import java.nio.charset.Charset;
import java.util.*;

public class CDSingerImpl implements CDSinger {
    Scanner sc = new Scanner(System.in);

    @Override
    public List<CD> getAllDetails() {
        return getData();
    }

    private List<CD> getData() {
        List<CD> CDList = new ArrayList<>();

        CD cd = null;
        for(int i=0;i<5;i++){
            cd = new CD();
            cd.setCdId(new Random().nextInt(1000));

            // generate random string
            //System.out.print("Enter the Singer Name: ");
            cd.setSinger(getAlphaNumericString(9));
            //System.out.print("Enter the Title: ");
            cd.setTitle(getAlphaNumericString(9));
            CDList.add(cd);
        }
        return CDList;
    }

    static String getAlphaNumericString(int n) {
        // length is bounded by 256 Character
        byte[] array = new byte[256];
        new Random().nextBytes(array);

        String randomString = new String(array, Charset.forName("UTF-8"));

        // Create a StringBuffer to store the result
        StringBuffer r = new StringBuffer();

        // Append first 20 alphanumeric characters
        // from the generated random String into the result
        for (int k = 0; k < randomString.length(); k++) {
            char ch = randomString.charAt(k);

            if (((ch >= 'a' && ch <= 'z')
                    || (ch >= 'A' && ch <= 'Z')
                    || (ch >= '0' && ch <= '9'))
                    && (n > 0)) {

                r.append(ch);
                n--;
            }
        }

        // return the resultant string
        return r.toString();
    }

}
