package com.assignment.one.models;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class CD {
    private long cdId;
    private String title;
    private String singer;

}
